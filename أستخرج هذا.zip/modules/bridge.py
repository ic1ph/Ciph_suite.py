
import subprocess
import json
import os
import sys
import time
import tempfile
import threading
from typing import Dict, List, Optional, Any
from datetime import datetime
import signal

class CiphBridge:
    def __init__(self):
        self.go_modules = {
            'ciph_brute': {
                'source': 'ciph_brute.go',
                'binary': 'ciph_brute.exe' if os.name == 'nt' else 'ciph_brute',
                'config_file': 'brute_config.json'
            }
        }
        
        self.python_modules = {
            'ciph_scanner': 'ciph_scanner.py',
            'ciph_sqli_dumper': 'ciph_sqli_dumper.py'
        }
        
        self.running_processes: Dict[str, subprocess.Popen] = {}
        self.module_results: Dict[str, Any] = {}
        
    def check_go_installed(self) -> bool:
        try:
            result = subprocess.run(['go', 'version'], capture_output=True, text=True, timeout=5)
            return result.returncode == 0
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return False
            
    def build_go_module(self, module_name: str) -> bool:
        if module_name not in self.go_modules:
            print(f"[X] Unknown Go module: {module_name}")
            return False
            
        module_info = self.go_modules[module_name]
        source_path = module_info['source']
        binary_path = module_info['binary']
        
        if not os.path.exists(source_path):
            print(f"[X] Source file not found: {source_path}")
            return False
            
        print(f"[*] Building {module_name} from {source_path}...")
        
        try:
            if not os.path.exists('go.mod'):
                subprocess.run(['go', 'mod', 'init', 'ciph-suite'], check=True, capture_output=True)
                
            subprocess.run(['go', 'mod', 'tidy'], check=True, capture_output=True)
            build_cmd = ['go', 'build', '-o', binary_path, source_path]
            result = subprocess.run(build_cmd, capture_output=True, text=True, timeout=60)
            
            if result.returncode == 0:
                print(f"[✓] Successfully built {module_name}")
                return True
            else:
                print(f"[X] Build failed for {module_name}: {result.stderr}")
                return False
                
        except subprocess.TimeoutExpired:
            print(f"[X] Build timeout for {module_name}")
            return False
        except Exception as e:
            print(f"[X] Build error for {module_name}: {e}")
            return False
            
    def create_go_config(self, module_name: str, config: Dict) -> str:
        if module_name not in self.go_modules:
            return None
            
        config_file = self.go_modules[module_name]['config_file']
        
        try:
            with open(config_file, 'w') as f:
                json.dump(config, f, indent=2)
                
            return config_file
            
        except Exception as e:
            print(f"[X] Failed to create config for {module_name}: {e}")
            return None
            
    def run_go_module(self, module_name: str, config: Optional[Dict] = None) -> bool:
        if not self.check_go_installed():
            print("[X] Go is not installed. Please install Go to use Go modules.")
            return False
            
        if module_name not in self.go_modules:
            print(f"[X] Unknown Go module: {module_name}")
            return False
            
        module_info = self.go_modules[module_name]
        binary_path = module_info['binary']
        
        if not os.path.exists(binary_path):
            if not self.build_go_module(module_name):
                return False
        if config:
            config_file = self.create_go_config(module_name, config)
            if config_file:
                os.environ['CIPH_CONFIG'] = config_file
                
        try:
            print(f"[*] Starting {module_name}...")
            process = subprocess.Popen(
                [f'./{binary_path}'] if os.name != 'nt' else [binary_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
                universal_newlines=True
            )
            
            self.running_processes[module_name] = process
            
            
            output_thread = threading.Thread(
                target=self._monitor_output,
                args=(module_name, process),
                daemon=True
            )
            output_thread.start()
            
            return True
            
        except Exception as e:
            print(f"[X] Failed to run {module_name}: {e}")
            return False
            
    def run_python_module(self, module_name: str, args: List[str] = None) -> bool:
        if module_name not in self.python_modules:
            print(f"[X] Unknown Python module: {module_name}")
            return False
            
        script_path = self.python_modules[module_name]
        
        if not os.path.exists(script_path):
            print(f"[X] Script not found: {script_path}")
            return False
            
        try:
            print(f"[*] Starting {module_name}...")
            
            cmd = [sys.executable, script_path]
            if args:
                cmd.extend(args)
                
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
                universal_newlines=True
            )
            
            self.running_processes[module_name] = process
            
            
            output_thread = threading.Thread(
                target=self._monitor_output,
                args=(module_name, process),
                daemon=True
            )
            output_thread.start()
            
            return True
            
        except Exception as e:
            print(f"[X] Failed to run {module_name}: {e}")
            return False
            
    def _monitor_output(self, module_name: str, process: subprocess.Popen):
        try:
            while True:
                output = process.stdout.readline()
                if output == '' and process.poll() is not None:
                    break
                if output:
                    print(f"[{module_name}] {output.strip()}")
                    
            
            stderr_output = process.stderr.read()
            if stderr_output:
                print(f"[{module_name} ERROR] {stderr_output}")
                
        except Exception as e:
            print(f"[{module_name} MONITOR ERROR] {e}")
            
    def wait_for_module(self, module_name: str, timeout: Optional[int] = None) -> int:
        if module_name not in self.running_processes:
            return -1
            
        process = self.running_processes[module_name]
        
        try:
            if timeout:
                process.wait(timeout=timeout)
            else:
                process.wait()
                
            return process.returncode
            
        except subprocess.TimeoutExpired:
            print(f"[!] Timeout waiting for {module_name}")
            self.terminate_module(module_name)
            return -1
            
    def terminate_module(self, module_name: str) -> bool:
        if module_name not in self.running_processes:
            return False
            
        process = self.running_processes[module_name]
        
        try:
            print(f"[*] Terminating {module_name}...")
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
                
            del self.running_processes[module_name]
            print(f"[✓] {module_name} terminated")
            return True
            
        except Exception as e:
            print(f"[X] Failed to terminate {module_name}: {e}")
            return False
            
    def terminate_all_modules(self):
        for module_name in list(self.running_processes.keys()):
            self.terminate_module(module_name)
            
    def get_module_status(self, module_name: str) -> Optional[str]:
        if module_name not in self.running_processes:
            return "not_running"
            
        process = self.running_processes[module_name]
        returncode = process.poll()
        
        if returncode is None:
            return "running"
        elif returncode == 0:
            return "completed"
        else:
            return f"failed_{returncode}"
            
    def list_available_modules(self) -> Dict[str, List[str]]:
        return {
            'go_modules': list(self.go_modules.keys()),
            'python_modules': list(self.python_modules.keys())
        }
        
    def cleanup(self):
        self.terminate_all_modules()
        for module_info in self.go_modules.values():
            config_file = module_info.get('config_file')
            if config_file and os.path.exists(config_file):
                try:
                    os.remove(config_file)
                except:
                    pass

class CiphModuleManager:
    def __init__(self):
        self.bridge = CiphBridge()
        self.session_id = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.results_dir = f"results_{self.session_id}"
        
        os.makedirs(self.results_dir, exist_ok=True)
        
    def run_scanner(self, target: str, options: Dict = None) -> bool:
        print(f"[*] Running Ciph-Scanner against {target}")
        
        args = [target]
        if options:
            for key, value in options.items():
                args.extend([f"--{key}", str(value)])
                
        success = self.bridge.run_python_module('ciph_scanner', args)
        
        if success:
            returncode = self.bridge.wait_for_module('ciph_scanner')
            return returncode == 0
            
        return False
        
    def run_brute(self, config: Dict) -> bool:
        print("[*] Running Ciph-Brute")
        go_config = {
            'target_url': config.get('target_url', ''),
            'username_field': config.get('username_field', 'username'),
            'password_field': config.get('password_field', 'password'),
            'wordlist_path': config.get('wordlist_path', 'wordlist.txt'),
            'threads': config.get('threads', 50),
            'timeout_seconds': config.get('timeout', 10),
            'use_proxies': config.get('use_proxies', False),
            'proxy_file': config.get('proxy_file', 'proxies.txt')
        }
        
        success = self.bridge.run_go_module('ciph_brute', go_config)
        
        if success:
            returncode = self.bridge.wait_for_module('ciph_brute')
            return returncode == 0
            
        return False
        
    def run_sqli_dumper(self, target: str, param: str, options: Dict = None) -> bool:
        print(f"[*] Running Ciph-SQLi-Dumper against {target}")
        
        args = [target, '--param', param]
        if options:
            for key, value in options.items():
                args.extend([f"--{key}", str(value)])
                
        success = self.bridge.run_python_module('ciph_sqli_dumper', args)
        
        if success:
            returncode = self.bridge.wait_for_module('ciph_sqli_dumper')
            return returncode == 0
            
        return False
        
    def run_comprehensive_test(self, target: str, options: Dict = None) -> Dict:
        results = {
            'target': target,
            'timestamp': datetime.now().isoformat(),
            'modules': {}
        }
        
        print(f"[*] Starting comprehensive test against {target}")
        
        try:
            print("\n" + "="*50)
            print("STEP 1: Vulnerability Scanning")
            print("="*50)
            scanner_success = self.run_scanner(target, options)
            results['modules']['scanner'] = {'success': scanner_success}
            print("\n" + "="*50)
            print("STEP 2: Brute Force Testing")
            print("="*50)
            if options and options.get('brute_config'):
                brute_success = self.run_brute(options['brute_config'])
                results['modules']['brute'] = {'success': brute_success}
            print("\n" + "="*50)
            print("STEP 3: SQL Injection Testing")
            print("="*50)
            if options and options.get('sqli_param'):
                sqli_success = self.run_sqli_dumper(target, options['sqli_param'], options)
                results['modules']['sqli'] = {'success': sqli_success}
            results_file = os.path.join(self.results_dir, 'comprehensive_test.json')
            with open(results_file, 'w') as f:
                json.dump(results, f, indent=2)
                
            print(f"\n[✓] Comprehensive test completed")
            print(f"[✓] Results saved to: {results_file}")
            
        except KeyboardInterrupt:
            print("\n[!] Comprehensive test interrupted")
        except Exception as e:
            print(f"[!] Error during comprehensive test: {e}")
        finally:
            self.bridge.cleanup()
            
        return results
        
    def interactive_mode(self):
        while True:
            print("\n" + "="*50)
            print("CIPH-SUITE Module Manager")
            print("="*50)
            
            modules = self.bridge.list_available_modules()
            
            print("Available modules:")
            print("1. Ciph-Scanner (Python)")
            print("2. Ciph-Brute (Go)")
            print("3. Ciph-SQLi-Dumper (Python)")
            print("4. Comprehensive Test")
            print("5. List running modules")
            print("6. Exit")
            
            choice = input("\n[?] Select option: ").strip()
            
            if choice == "1":
                target = input("[?] Target URL: ").strip()
                self.run_scanner(target)
                
            elif choice == "2":
                config = {
                    'target_url': input("[?] Target URL: ").strip(),
                    'username_field': input("[?] Username field (default: username): ").strip() or "username",
                    'password_field': input("[?] Password field (default: password): ").strip() or "password",
                    'wordlist_path': input("[?] Wordlist path: ").strip(),
                    'threads': int(input("[?] Threads (default: 50): ").strip() or "50")
                }
                self.run_brute(config)
                
            elif choice == "3":
                target = input("[?] Target URL: ").strip()
                param = input("[?] Vulnerable parameter: ").strip()
                self.run_sqli_dumper(target, param)
                
            elif choice == "4":
                target = input("[?] Target URL: ").strip()
                self.run_comprehensive_test(target)
                
            elif choice == "5":
                running = list(self.bridge.running_processes.keys())
                if running:
                    print(f"Running modules: {', '.join(running)}")
                else:
                    print("No modules currently running")
                    
            elif choice == "6":
                break
                
            else:
                print("[X] Invalid choice")
                
        self.bridge.cleanup()

def main():
    try:
        manager = CiphModuleManager()
        
        if len(sys.argv) > 1:
             
            if sys.argv[1] == "--interactive":
                manager.interactive_mode()
            else:
                print("Usage: python bridge.py --interactive")
        else:
             
            manager.interactive_mode()
            
    except KeyboardInterrupt:
        print("\n[!] Exiting...")
    except Exception as e:
        print(f"[!] Error: {e}")

if __name__ == "__main__":
    main()
