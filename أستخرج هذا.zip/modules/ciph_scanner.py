

import asyncio
import random
import time
import json
import sys
import os
from datetime import datetime
from urllib.parse import urljoin, urlparse
from typing import List, Dict, Set

try:
    from playwright.async_api import async_playwright, BrowserContext, Page
    from bs4 import BeautifulSoup
    import requests
except ImportError as e:
    print(f"[X] Missing dependencies: {e}")
    print("[!] Install with: pip install playwright beautifulsoup4 requests")
    input("[!] Press Enter to continue...")
    sys.exit(1)

class CiphScanner:
    def __init__(self):
        self.user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/121.0",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:109.0) Gecko/20100101 Firefox/121.0"
        ]
        
        self.referrers = [
            "https://www.google.com/",
            "https://www.bing.com/",
            "https://duckduckgo.com/",
            "https://www.reddit.com/",
            "https://github.com/"
        ]
        
        self.origins = [
            "https://www.google.com",
            "https://www.bing.com",
            "https://duckduckgo.com",
            "null"
        ]
        
        self.vulnerability_signatures = {
            "sql_injection": [
                "error in your SQL syntax", "mysql_fetch_array()", "mysql_num_rows()",
                "ORA-[0-9]{5}", "Microsoft OLE DB Provider", "ODBC Microsoft Access Driver",
                "PostgreSQL query failed", "Warning: pg_"
            ],
            "xss": [
                "<script>alert(", "javascript:alert(", "onerror=", "onload=",
                "XSS detected", "Cross-site scripting"
            ],
            "lfi": [
                "root:", "bin/bash", "etc/passwd", "windows/system32",
                "Permission denied", "No such file or directory"
            ],
            "rce": [
                "sh: command not found", "cmd.exe", "powershell", "bash:",
                "uid=", "gid=", "groups="
            ]
        }
        
        self.scanned_urls: Set[str] = set()
        self.vulnerabilities: List[Dict] = []
        
    def get_random_headers(self) -> Dict[str, str]:
        return {
            "User-Agent": random.choice(self.user_agents),
            "Referer": random.choice(self.referrers),
            "Origin": random.choice(self.origins),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate",
            "DNT": "1",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1"
        }
        
    async def create_stealth_context(self, playwright) -> BrowserContext:
        launch_options = {
            "headless": True,
            "args": [
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage",
                "--disable-accelerated-2d-canvas",
                "--no-first-run",
                "--no-zygote",
                "--disable-gpu"
            ]
        }
        
        browser = await playwright.chromium.launch(**launch_options)
        context = await browser.new_context(
            user_agent=random.choice(self.user_agents),
            viewport={"width": 1920, "height": 1080},
            java_script_enabled=True
        )
        
        await context.add_init_script("""
            Object.defineProperty(navigator, 'webdriver', {
                get: () => undefined,
            });
            
            Object.defineProperty(navigator, 'plugins', {
                get: () => [1, 2, 3, 4, 5],
            });
            
            Object.defineProperty(navigator, 'languages', {
                get: () => ['en-US', 'en'],
            });
        """)
        
        return context
        
    async def bypass_cloudflare(self, page: Page, url: str) -> bool:
        try:
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            
            await page.wait_for_timeout(random.randint(2000, 4000))
            
            if await page.query_selector('[data-ray]') or await page.query_selector('.cf-browser-verification'):
                print("[*] Cloudflare challenge detected, bypassing...")
                await page.wait_for_timeout(5000)
                
                if await page.query_selector('#challenge-form'):
                    await page.wait_for_timeout(10000)
                    
            return True
            
        except Exception as e:
            print(f"[!] Cloudflare bypass failed: {e}")
            return False
            
    async def scan_page(self, page: Page, url: str) -> Dict:
        results = {"url": url, "vulnerabilities": [], "forms": [], "links": []}
        
        try:
            content = await page.content()
            soup = BeautifulSoup(content, 'lxml')
            
            forms = soup.find_all('form')
            for form in forms:
                form_data = {
                    "action": form.get('action', ''),
                    "method": form.get('method', 'get').lower(),
                    "inputs": []
                }
                
                for input_tag in form.find_all(['input', 'textarea']):
                    input_data = {
                        "name": input_tag.get('name', ''),
                        "type": input_tag.get('type', 'text'),
                        "value": input_tag.get('value', '')
                    }
                    form_data["inputs"].append(input_data)
                    
                results["forms"].append(form_data)
                
            links = soup.find_all('a', href=True)
            for link in links:
                href = link['href']
                if href.startswith(('http', '/')):
                    full_url = urljoin(url, href)
                    if urlparse(full_url).netloc == urlparse(url).netloc:
                        results["links"].append(full_url)
                        
            await self.test_sql_injection(page, url, results)
            await self.test_xss(page, url, results)
            await self.test_lfi(page, url, results)
            
        except Exception as e:
            print(f"[!] Error scanning {url}: {e}")
            
        return results
        
    async def test_sql_injection(self, page: Page, url: str, results: Dict):
        payloads = [
            "'", '"', "\\", "1' OR '1'='1", "1\" OR \"1\"=\"1",
            "' UNION SELECT NULL--", "' AND 1=CONVERT(int, (SELECT @@version))--"
        ]
        
        for payload in payloads:
            try:
                test_url = f"{url}?id={payload}" if '?' in url else f"{url}?id={payload}"
                
                await page.goto(test_url, wait_until="domcontentloaded", timeout=10000)
                content = await page.content()
                
                for signature in self.vulnerability_signatures["sql_injection"]:
                    if signature.lower() in content.lower():
                        results["vulnerabilities"].append({
                            "type": "SQL Injection",
                            "severity": "High",
                            "payload": payload,
                            "url": test_url,
                            "evidence": signature
                        })
                        break
                        
            except Exception:
                continue
                
    async def test_xss(self, page: Page, url: str, results: Dict):
        payloads = [
            "<script>alert('XSS')</script>", "javascript:alert('XSS')",
            "<img src=x onerror=alert('XSS')>", "<svg onload=alert('XSS')>"
        ]
        
        for payload in payloads:
            try:
                test_url = f"{url}?search={payload}" if '?' in url else f"{url}?search={payload}"
                
                await page.goto(test_url, wait_until="domcontentloaded", timeout=10000)
                
                try:
                    await page.wait_for_function('() => document.querySelector("script") || document.querySelector("img[onerror]")', timeout=5000)
                    results["vulnerabilities"].append({
                        "type": "Cross-Site Scripting (XSS)",
                        "severity": "High",
                        "payload": payload,
                        "url": test_url
                    })
                except:
                    pass
                    
            except Exception:
                continue
                
    async def test_lfi(self, page: Page, url: str, results: Dict):
        payloads = [
            "../../../etc/passwd", "..\\..\\..\\windows\\system32\\drivers\\etc\\hosts",
            "/etc/passwd", "file:///etc/passwd"
        ]
        
        for payload in payloads:
            try:
                test_url = f"{url}?file={payload}" if '?' in url else f"{url}?file={payload}"
                
                await page.goto(test_url, wait_until="domcontentloaded", timeout=10000)
                content = await page.content()
                
                for signature in self.vulnerability_signatures["lfi"]:
                    if signature.lower() in content.lower():
                        results["vulnerabilities"].append({
                            "type": "Local File Inclusion (LFI)",
                            "severity": "Critical",
                            "payload": payload,
                            "url": test_url,
                            "evidence": signature
                        })
                        break
                        
            except Exception:
                continue
                
    async def scan_target(self, target_url: str):
        print(f"[*] Starting scan of: {target_url}")
        print(f"[*] Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        async with async_playwright() as playwright:
            context = await self.create_stealth_context(playwright)
            page = await context.new_page()
            
            if not await self.bypass_cloudflare(page, target_url):
                print("[!] Failed to bypass Cloudflare protection")
                return
                
            results = await self.scan_page(page, target_url)
            self.vulnerabilities.extend(results["vulnerabilities"])
            
            for link in results["links"][:10]:
                if link not in self.scanned_urls:
                    self.scanned_urls.add(link)
                    try:
                        await page.goto(link, wait_until="domcontentloaded", timeout=15000)
                        page_results = await self.scan_page(page, link)
                        self.vulnerabilities.extend(page_results["vulnerabilities"])
                        print(f"[*] Scanned: {link}")
                    except Exception as e:
                        print(f"[!] Failed to scan {link}: {e}")
                        
            await context.close()
            
    def display_results(self):
        print("\n" + "="*80)
        print("SCAN RESULTS")
        print("="*80)
        
        if not self.vulnerabilities:
            print("[✓] No vulnerabilities found")
        else:
            for i, vuln in enumerate(self.vulnerabilities, 1):
                print(f"\n[{i}] {vuln['type']}")
                print(f"    Severity: {vuln['severity']}")
                print(f"    URL: {vuln['url']}")
                print(f"    Payload: {vuln.get('payload', 'N/A')}")
                if 'evidence' in vuln:
                    print(f"    Evidence: {vuln['evidence']}")
                    
        print(f"\nTotal Vulnerabilities Found: {len(self.vulnerabilities)}")
        
    def save_results(self, target_url: str):
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"scan_results_{timestamp}.json"
        
        report = {
            "target": target_url,
            "timestamp": datetime.now().isoformat(),
            "vulnerabilities": self.vulnerabilities,
            "total_scanned": len(self.scanned_urls)
        }
        
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)
            
        print(f"\n[✓] Results saved to: {filename}")
        
    async def run(self):
        try:
            print("\n" + "="*60)
            print("CIPH-SCANNER - Vulnerability Hunter")
            print("="*60)
            
            target_url = input("[?] Target URL: ").strip()
            if not target_url.startswith(('http://', 'https://')):
                target_url = 'https://' + target_url
                
            print(f"[*] Target: {target_url}")
            print("[*] Initializing stealth browser...")
            
            await self.scan_target(target_url)
            self.display_results()
            
            save_choice = input("\n[?] Save results? (y/n): ").strip().lower()
            if save_choice == 'y':
                self.save_results(target_url)
                
        except KeyboardInterrupt:
            print("\n[!] Scan interrupted by user")
        except Exception as e:
            print(f"[!] Scan error: {e}")
        finally:
            input("\n[!] Press Enter to continue...")

async def main():
    scanner = CiphScanner()
    await scanner.run()

if __name__ == "__main__":
    asyncio.run(main())
